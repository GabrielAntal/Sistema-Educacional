package Model;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;





public class Conexao_bd {
    public  String url = "jdbc:postgresql://localhost:5432/Escola";
    public String usuario = "postgres";
    public  String senha = "root";
    
    
    
    
    private  Connection conexao = null;
    private  Statement stmt = null;
    
    public  boolean conecta (){
        try {
            conexao = DriverManager.getConnection(url, usuario, senha);
             JOptionPane.showMessageDialog(null, "conexao com sucesso");
            return true;
        }
            catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "nao deu certo a conexao");
                return false;
            }
    }
   
    public  boolean tabela_creates(){
        try {
            conexao = DriverManager.getConnection(url, usuario, senha);
            stmt = conexao.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS ALUNO ("+ 
 "          cod_aluno serial,  "+
 "          nome_aluno varchar NOT NULL, "+
            " sobrenome varchar NOT NULL, "+
            " rg_aluno varchar NOT NULL, "+
            " data_nasc DATE, "+
              " mediafinal decimal(2,1), "+
              "resultado varchar, "+  
             "cod_disciplina serial, "+
            " nota_aluno DECIMAL(2,1) NOT NULL, "+
            " falta_aluno integer NOT NULL, "+
            " CONSTRAINT COD_ALUNO PRIMARY KEY (cod_aluno) "+
               
            ");"+
                    
          " create type tipo_usuario as ENUM ('P','D','S');"+      
           
          " CREATE TABLE IF NOT EXISTS PROFISSIONAL ("+
            " cod_prof SERIAL, "+
            " nome_prof varchar NOT NULL, "+
            " email_prof varchar NOT NULL, "+
            " senha varchar NOT NULL, "+
                   
            " tipo_usu tipo_usuario NOT NULL, "+
            " cpf varchar NOT NULL, "+
            "cod_disciplina serial, "+        
            " CONSTRAINT cod_prof PRIMARY KEY (cod_prof) "+
            ");"+  
           
            " CREATE TABLE IF NOT EXISTS PERIODO ("+
            " cod_per SERIAL PRIMARY KEY, "+
            " descricao_per varchar NOT NULL "+
            ");"+
            
           " CREATE TABLE IF NOT EXISTS BLOCO ("+
            " cod_blo SERIAL, "+
           " descricao_blo varchar NOT NULL, "+
            " CONSTRAINT COD_BLO PRIMARY KEY(cod_blo) "+
             ");"+ 
                    
           
           " CREATE TABLE IF NOT EXISTS DISCIPLINA ("+
            " cod_disc SERIAL, "+
            " nome_disc varchar, "+
                    "cod_sa SERIAL, "+
                     "cod_professor serial, "+
            " turma varchar, "+
            " CONSTRAINT cod_disc PRIMARY KEY (cod_disc) "+
            
             ");"+ 
            
            " CREATE TABLE IF NOT EXISTS SALA ("+
            " cod_sala SERIAL, "+
              " cod_bloc serial, "+
                "    cod_alu integer not null, "+
            "cod_periodo serial, "+        
               "status varchar, "+     
            " descricao_sala varchar NOT NULL, "+
            " CONSTRAINT cod_sala PRIMARY KEY(cod_sala) "+
           
         ");";  
            stmt.executeUpdate(sql);
             JOptionPane.showMessageDialog(null, "deu certo ao criar tabela");
            stmt.close();
            conexao.close();
            return true;
        } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "nao deu certo ao criar tabela");
            return false;
        }
        
    }
    
    
    
    public  boolean modify(){
          try {
            conexao = DriverManager.getConnection(url, usuario, senha);
            stmt = conexao.createStatement();
            
            String sql = 
                           
               "ALTER TABLE SALA ADD CONSTRAINT cod_bloco_fk\n" +
              "FOREIGN KEY (cod_bloc)\n" +
              "REFERENCES bloco (COD_BLO);\n" +
                    
            "ALTER TABLE SALA ADD CONSTRAINT cod_alunos_fk\n" +
             " FOREIGN KEY (cod_alu)\n"  +
             "REFERENCES ALUNO (COD_ALUNO);\n" +
                    
                    
                    
            "ALTER TABLE DISCIPLINA ADD CONSTRAINT cod_salas_fk\n" +
              " FOREIGN KEY (cod_sa) \n" +
              "REFERENCES SALA (cod_sala);\n" +
                    
                    
            "ALTER TABLE DISCIPLINA ADD CONSTRAINT cod_profs_fk\n" +
                     "FOREIGN KEY (cod_professor)\n " +
                     "REFERENCES PROFISSIONAL(cod_prof);\n" +
           
                    
                    
             "ALTER TABLE DISCIPLINA ADD CONSTRAINT cod_per_fk\n" +
                     " FOREIGN KEY (cod_periodo)\n" +
                     " REFERENCES PERIODO (cod_per);"+
                    
                    
             "ALTER TABLE PROFISSIONAL ADD CONSTRAINT cod_disc_fk\n "+
                     "FOREIGN KEY (cod_disciplina)\n" +
                     " REFERENCES DISCIPLINA (cod_disc);"+
            
                    
               "ALTER TABLE ALUNO ADD CONSTRAINT cod_disc_fk\n "+
                     "FOREIGN KEY (cod_disciplina)\n" +
                     " REFERENCES DISCIPLINA (cod_disc);"+
                      
                    
                    
                    " create type tipo_usuario as ENUM ('P','D','S'); "+
            "INSERT INTO PROFISSIONAL VALUES (1, 'Diretor', 'admin@gmail.com', 'admin', 'D', '');"
            +"insert into profissional (cod_prof, nome_prof,email_prof, senha,tipo_usu,cpf) VALUES(1,'diretor','admin@gmail.com','admin','D','');";
        
        stmt.executeUpdate(sql);
            stmt.close();
            conexao.close();
            return true;
        } catch (SQLException e) {
              JOptionPane.showMessageDialog(null, "nao deu certo no modify");
            return false;
        }


    
    }
    
    
}





