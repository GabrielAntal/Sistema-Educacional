/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.educacional;

import Model.Conexao_bd;
import Views.TelaLogin;
import Views.telainicial;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 *
 * @author Willian
 */
public class SistemaEducacional {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       try { 
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel"); 
   } catch(Exception ignored){
      }
        TelaLogin te= new TelaLogin();
        te.show();
        //telainicial t = new telainicial();
             
       // t.show();
        Conexao_bd c = new Conexao_bd();
        if(c.conecta()){
             JOptionPane.showMessageDialog(null, "conexao sucesso");
        }else{
             JOptionPane.showMessageDialog(null, "erro na conexao");
        }
       
        if(c.tabela_creates()){
             JOptionPane.showMessageDialog(null, " certo no modify");
        }else{
             JOptionPane.showMessageDialog(null, "nao deu certo no modify");
        }
        
    }
    
}
